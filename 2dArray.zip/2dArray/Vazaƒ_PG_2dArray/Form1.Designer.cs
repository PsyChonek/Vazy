﻿namespace Vazač_PG_2dArray
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.vypis = new System.Windows.Forms.Label();
            this.radek = new System.Windows.Forms.TextBox();
            this.sloupec = new System.Windows.Forms.TextBox();
            this.radky = new System.Windows.Forms.Label();
            this.sloupce = new System.Windows.Forms.Label();
            this.spust = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // vypis
            // 
            this.vypis.AutoSize = true;
            this.vypis.Location = new System.Drawing.Point(285, 9);
            this.vypis.Name = "vypis";
            this.vypis.Size = new System.Drawing.Size(35, 13);
            this.vypis.TabIndex = 0;
            this.vypis.Text = "label1";
            this.vypis.Click += new System.EventHandler(this.vypis_Click);
            // 
            // radek
            // 
            this.radek.Location = new System.Drawing.Point(134, 12);
            this.radek.Name = "radek";
            this.radek.Size = new System.Drawing.Size(100, 20);
            this.radek.TabIndex = 1;
            this.radek.TextChanged += new System.EventHandler(this.radek_TextChanged);
            // 
            // sloupec
            // 
            this.sloupec.Location = new System.Drawing.Point(134, 38);
            this.sloupec.Name = "sloupec";
            this.sloupec.Size = new System.Drawing.Size(100, 20);
            this.sloupec.TabIndex = 2;
            this.sloupec.TextChanged += new System.EventHandler(this.sloupec_TextChanged);
            // 
            // radky
            // 
            this.radky.AutoSize = true;
            this.radky.Location = new System.Drawing.Point(25, 15);
            this.radky.Name = "radky";
            this.radky.Size = new System.Drawing.Size(66, 13);
            this.radky.TabIndex = 3;
            this.radky.Text = "Počet řádků";
            // 
            // sloupce
            // 
            this.sloupce.AutoSize = true;
            this.sloupce.Location = new System.Drawing.Point(25, 45);
            this.sloupce.Name = "sloupce";
            this.sloupce.Size = new System.Drawing.Size(75, 13);
            this.sloupce.TabIndex = 4;
            this.sloupce.Text = "Počet sloupců";
            // 
            // spust
            // 
            this.spust.Location = new System.Drawing.Point(134, 64);
            this.spust.Name = "spust";
            this.spust.Size = new System.Drawing.Size(100, 30);
            this.spust.TabIndex = 5;
            this.spust.Text = "spust";
            this.spust.UseVisualStyleBackColor = true;
            this.spust.Click += new System.EventHandler(this.spust_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.spust);
            this.Controls.Add(this.sloupce);
            this.Controls.Add(this.radky);
            this.Controls.Add(this.sloupec);
            this.Controls.Add(this.radek);
            this.Controls.Add(this.vypis);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label vypis;
        private System.Windows.Forms.TextBox radek;
        private System.Windows.Forms.TextBox sloupec;
        private System.Windows.Forms.Label radky;
        private System.Windows.Forms.Label sloupce;
        private System.Windows.Forms.Button spust;
    }
}

