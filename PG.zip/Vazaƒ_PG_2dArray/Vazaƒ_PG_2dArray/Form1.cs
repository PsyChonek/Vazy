﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vazač_PG_2dArray
{
    public partial class Form1 : Form
    {
        int[,] PoleCisel;
        Random NahodneCisla = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void vypis_Click(object sender, EventArgs e)
        {

        }

        private void sloupec_TextChanged(object sender, EventArgs e)
        {

        }

        private void radek_TextChanged(object sender, EventArgs e)
        {

        }

        private void spust_Click(object sender, EventArgs e)
        {
            string label = "";

            PoleCisel = new int[Convert.ToInt32(radek.Text), int.Parse(sloupec.Text)];
            Random NahodneCisla = new Random();

            for (int P = 0; P < PoleCisel.GetLength(0); P++)
            {
                for (int C = 0; C <PoleCisel.GetLength(1); C++)
                {
                    PoleCisel[P, C] = NahodneCisla.Next(1, 11);
                    label += PoleCisel[P, C] + " " ;
                }

                label += '\n';
            }
            vypis.Text = label;
        }
    }
}
