﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vazač___PG___Pole
{
    public partial class Form1 : Form
    {

        float prumc = 0;
        int[] PoleCisel = new int[20];
        Random NahodneCisla = new Random();

        public Form1()
        {
            InitializeComponent();

            textBox1.Enabled = false;

            for (int P = 0; P < PoleCisel.Length; P++)
            {
                PoleCisel[P] = NahodneCisla.Next(1, 1001);
                prumc += PoleCisel[P];
            }

            prumc = prumc / 20;

            foreach (int Cislo in PoleCisel)
            {
                vypis.Items.Add(Cislo.ToString());
            }
            prum.Items.Add("Průměr je: " + prumc.ToString());

        }

        private void vypis_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        public void prumup_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = false;

        }

        private void prumdown_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = false;

        }

        private void odchylka_CheckedChanged(object sender, EventArgs e)
        {

            textBox1.Enabled = true;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void prum_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cisla_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
        }


        public void tlacitko_Click(object sender, EventArgs e)
        {

            if (!prumup.Checked && !prumdown.Checked && !odchylka.Checked || cisla.Checked)
            {
                vypis.Items.Clear();
                prum.Items.Clear();
                for (int P = 0; P < PoleCisel.Length; P++)
                {
                    PoleCisel[P] = NahodneCisla.Next(1, 1001);
                    prumc += PoleCisel[P];
                }

                prumc = prumc / 20;

                foreach (int Cislo in PoleCisel)
                {
                    vypis.Items.Add(Cislo.ToString());
                }
                prum.Items.Add("Průměr je: " + prumc.ToString());

            }

            if (prumup.Checked)
            {
                vypis.Items.Clear();
                foreach (int Cislo in PoleCisel)
                {
                    if (prumc < Cislo)
                    {
                        vypis.Items.Add(Cislo.ToString());
                    }
                }
            }

            if (prumdown.Checked)
            {
                vypis.Items.Clear();
                foreach (int Cislo in PoleCisel)
                {
                    if (prumc > Cislo)
                    {
                        vypis.Items.Add(Cislo.ToString());
                    }
                }
            }


            if (odchylka.Checked)
            {
                vypis.Items.Clear();
                foreach (int Cislo in PoleCisel)
                {
                    if (prumc + int.Parse(textBox1.Text) > Cislo && prumc - int.Parse(textBox1.Text) < Cislo)
                    {
                        vypis.Items.Add(Cislo.ToString());
                    }
                }
            }



        }


    }
}
