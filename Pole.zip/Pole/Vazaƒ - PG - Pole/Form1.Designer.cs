﻿namespace Vazač___PG___Pole
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.vypis = new System.Windows.Forms.ListBox();
            this.odchylka = new System.Windows.Forms.RadioButton();
            this.prumdown = new System.Windows.Forms.RadioButton();
            this.prumup = new System.Windows.Forms.RadioButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.prum = new System.Windows.Forms.ListBox();
            this.tlacitko = new System.Windows.Forms.Button();
            this.cisla = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // vypis
            // 
            this.vypis.FormattingEnabled = true;
            this.vypis.Location = new System.Drawing.Point(12, 12);
            this.vypis.Name = "vypis";
            this.vypis.Size = new System.Drawing.Size(647, 277);
            this.vypis.TabIndex = 0;
            this.vypis.SelectedIndexChanged += new System.EventHandler(this.vypis_SelectedIndexChanged);
            // 
            // odchylka
            // 
            this.odchylka.AutoSize = true;
            this.odchylka.Location = new System.Drawing.Point(542, 381);
            this.odchylka.Name = "odchylka";
            this.odchylka.Size = new System.Drawing.Size(70, 17);
            this.odchylka.TabIndex = 1;
            this.odchylka.TabStop = true;
            this.odchylka.Text = "Odchylka";
            this.odchylka.UseVisualStyleBackColor = true;
            this.odchylka.CheckedChanged += new System.EventHandler(this.odchylka_CheckedChanged);
            // 
            // prumdown
            // 
            this.prumdown.AutoSize = true;
            this.prumdown.Location = new System.Drawing.Point(358, 381);
            this.prumdown.Name = "prumdown";
            this.prumdown.Size = new System.Drawing.Size(104, 17);
            this.prumdown.TabIndex = 2;
            this.prumdown.TabStop = true;
            this.prumdown.Text = "Nižší než průměr";
            this.prumdown.UseVisualStyleBackColor = true;
            this.prumdown.CheckedChanged += new System.EventHandler(this.prumdown_CheckedChanged);
            // 
            // prumup
            // 
            this.prumup.AutoSize = true;
            this.prumup.Location = new System.Drawing.Point(175, 381);
            this.prumup.Name = "prumup";
            this.prumup.Size = new System.Drawing.Size(105, 17);
            this.prumup.TabIndex = 3;
            this.prumup.TabStop = true;
            this.prumup.Text = "Větší než průměr";
            this.prumup.UseVisualStyleBackColor = true;
            this.prumup.CheckedChanged += new System.EventHandler(this.prumup_CheckedChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(530, 405);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 4;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // prum
            // 
            this.prum.FormattingEnabled = true;
            this.prum.Location = new System.Drawing.Point(12, 307);
            this.prum.Name = "prum";
            this.prum.Size = new System.Drawing.Size(189, 30);
            this.prum.TabIndex = 5;
            this.prum.SelectedIndexChanged += new System.EventHandler(this.prum_SelectedIndexChanged);
            // 
            // tlacitko
            // 
            this.tlacitko.Location = new System.Drawing.Point(266, 307);
            this.tlacitko.Name = "tlacitko";
            this.tlacitko.Size = new System.Drawing.Size(129, 30);
            this.tlacitko.TabIndex = 6;
            this.tlacitko.Text = "Spust";
            this.tlacitko.UseVisualStyleBackColor = true;
            this.tlacitko.Click += new System.EventHandler(this.tlacitko_Click);
            // 
            // cisla
            // 
            this.cisla.AutoSize = true;
            this.cisla.Location = new System.Drawing.Point(29, 381);
            this.cisla.Name = "cisla";
            this.cisla.Size = new System.Drawing.Size(76, 17);
            this.cisla.TabIndex = 7;
            this.cisla.TabStop = true;
            this.cisla.Text = "Nový čísla";
            this.cisla.UseVisualStyleBackColor = true;
            this.cisla.CheckedChanged += new System.EventHandler(this.cisla_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(676, 450);
            this.Controls.Add(this.cisla);
            this.Controls.Add(this.tlacitko);
            this.Controls.Add(this.prum);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.prumup);
            this.Controls.Add(this.prumdown);
            this.Controls.Add(this.odchylka);
            this.Controls.Add(this.vypis);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox vypis;
        private System.Windows.Forms.RadioButton odchylka;
        private System.Windows.Forms.RadioButton prumdown;
        private System.Windows.Forms.RadioButton prumup;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ListBox prum;
        private System.Windows.Forms.Button tlacitko;
        private System.Windows.Forms.RadioButton cisla;
    }
}

