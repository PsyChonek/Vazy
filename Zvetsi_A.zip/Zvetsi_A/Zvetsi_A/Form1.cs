﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zvetsi_A
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }

        public class Cisla
        {
            public double Acislo;
            public double Bcislo;
        }

        public void button1_Click(object sender, EventArgs e)
        {
            // Předání 

           double A = Double.Parse(Vstup1.Text);
           double B = Double.Parse(Vstup2.Text);

            Zvetsi_A_Secti(A, B);
            Zmensi_A_Vynasob(A, B);

            Vystup.Text = A + " " + B;

            // Odkaz

            Cisla c = new Cisla();
            c.Acislo = Double.Parse(Vstup1.Text);
            c.Bcislo = Double.Parse(Vstup2.Text);
   
            Zvetsi_A_Secti_Odkaz(c);
            Zmensi_A_Vynasob_Odkaz(c);

            VystupOdkaz.Text = c.Acislo + " " + c.Bcislo;
        }

        // Předání

        private void Zvetsi_A_Secti(double A, double B)
        {
            A++;
            B++;
            double AB = A + B;
            Secti.Text = AB + "";
        }

        private void Zmensi_A_Vynasob(double A, double B)
        {
            A--;
            B--;
            double AB = A * B;
            Nasob.Text = AB + "";
        }

        // Odkaz

        public void Zvetsi_A_Secti_Odkaz(Cisla obj)
        {
            obj.Acislo++;
            obj.Bcislo++;
            double AB = obj.Acislo + obj.Bcislo;
            SectiOdkaz.Text = AB + "";

        }

        public void Zmensi_A_Vynasob_Odkaz(Cisla obj)
        {
            obj.Acislo--;
            obj.Bcislo--;
            double AB = obj.Acislo * obj.Bcislo;
            NasobOdkaz.Text = AB + "";
        }

    }
}
