﻿namespace Zvetsi_A
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.Vstup1 = new System.Windows.Forms.TextBox();
            this.Vstup2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Secti = new System.Windows.Forms.Label();
            this.Nasob = new System.Windows.Forms.Label();
            this.Vystup = new System.Windows.Forms.Label();
            this.SectiOdkaz = new System.Windows.Forms.Label();
            this.NasobOdkaz = new System.Windows.Forms.Label();
            this.VystupOdkaz = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Vstup1
            // 
            this.Vstup1.Location = new System.Drawing.Point(32, 12);
            this.Vstup1.Name = "Vstup1";
            this.Vstup1.Size = new System.Drawing.Size(100, 20);
            this.Vstup1.TabIndex = 0;
            // 
            // Vstup2
            // 
            this.Vstup2.Location = new System.Drawing.Point(139, 12);
            this.Vstup2.Name = "Vstup2";
            this.Vstup2.Size = new System.Drawing.Size(100, 20);
            this.Vstup2.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(32, 44);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(207, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Operace";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Secti
            // 
            this.Secti.AutoSize = true;
            this.Secti.Location = new System.Drawing.Point(97, 134);
            this.Secti.Name = "Secti";
            this.Secti.Size = new System.Drawing.Size(35, 13);
            this.Secti.TabIndex = 3;
            this.Secti.Text = "label1";
            // 
            // Nasob
            // 
            this.Nasob.AutoSize = true;
            this.Nasob.Location = new System.Drawing.Point(96, 172);
            this.Nasob.Name = "Nasob";
            this.Nasob.Size = new System.Drawing.Size(35, 13);
            this.Nasob.TabIndex = 4;
            this.Nasob.Text = "label2";
            // 
            // Vystup
            // 
            this.Vystup.AutoSize = true;
            this.Vystup.Location = new System.Drawing.Point(96, 226);
            this.Vystup.Name = "Vystup";
            this.Vystup.Size = new System.Drawing.Size(35, 13);
            this.Vystup.TabIndex = 5;
            this.Vystup.Text = "label3";
            // 
            // SectiOdkaz
            // 
            this.SectiOdkaz.AutoSize = true;
            this.SectiOdkaz.Location = new System.Drawing.Point(205, 134);
            this.SectiOdkaz.Name = "SectiOdkaz";
            this.SectiOdkaz.Size = new System.Drawing.Size(35, 13);
            this.SectiOdkaz.TabIndex = 6;
            this.SectiOdkaz.Text = "label1";
            // 
            // NasobOdkaz
            // 
            this.NasobOdkaz.AutoSize = true;
            this.NasobOdkaz.Location = new System.Drawing.Point(205, 172);
            this.NasobOdkaz.Name = "NasobOdkaz";
            this.NasobOdkaz.Size = new System.Drawing.Size(35, 13);
            this.NasobOdkaz.TabIndex = 7;
            this.NasobOdkaz.Text = "label1";
            // 
            // VystupOdkaz
            // 
            this.VystupOdkaz.AutoSize = true;
            this.VystupOdkaz.Location = new System.Drawing.Point(204, 226);
            this.VystupOdkaz.Name = "VystupOdkaz";
            this.VystupOdkaz.Size = new System.Drawing.Size(35, 13);
            this.VystupOdkaz.TabIndex = 8;
            this.VystupOdkaz.Text = "label1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Sečti";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 172);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Násob";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 226);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Vstupní čísla";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(76, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Volání hodnoty";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(170, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Odkaz na hodnotu";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(274, 258);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.VystupOdkaz);
            this.Controls.Add(this.NasobOdkaz);
            this.Controls.Add(this.SectiOdkaz);
            this.Controls.Add(this.Vystup);
            this.Controls.Add(this.Nasob);
            this.Controls.Add(this.Secti);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Vstup2);
            this.Controls.Add(this.Vstup1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Vstup1;
        private System.Windows.Forms.TextBox Vstup2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label Secti;
        private System.Windows.Forms.Label Nasob;
        private System.Windows.Forms.Label Vystup;
        private System.Windows.Forms.Label SectiOdkaz;
        private System.Windows.Forms.Label NasobOdkaz;
        private System.Windows.Forms.Label VystupOdkaz;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

