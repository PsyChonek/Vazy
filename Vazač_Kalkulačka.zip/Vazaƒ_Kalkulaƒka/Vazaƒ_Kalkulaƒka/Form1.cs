﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vazač_Kalkulačka
{
    public partial class Form1 : Form
    {
        int Operace = 0;    

        public Form1()
        {
            InitializeComponent();
        }
        private void Plus_Click(object sender, EventArgs e)
        {
            textBox2.Visible = true;
            Operace = 1;
            Čísla.Visible = false;
        }
        private void Minus_Click(object sender, EventArgs e)
        {
            textBox2.Visible = true;
            Operace = 2;
            Čísla.Visible = false;
        }
        private void Krát_Click(object sender, EventArgs e)
        {
            textBox2.Visible = true;
            Operace = 3;
            Čísla.Visible = false;
        }
        private void Děleno_Click(object sender, EventArgs e)
        {
            textBox2.Visible = true;
            Operace = 4;
            Čísla.Visible = false;
        }

        private void Mocnina_Click(object sender, EventArgs e)
        {
            Vysledek.Text = "= " + MocniFn(double.Parse(textBox1.Text));
            textBox2.Visible = false;
            Čísla.Visible = false;
        }

        private void Odmocnina_Click(object sender, EventArgs e)
        {
            Vysledek.Text = "= " + OdmocniFn(double.Parse(textBox1.Text));
            textBox2.Visible = false;
            Čísla.Visible = false;
        }

        private float SečtiFn(float Cislo1, float Cislo2)
        {
            return Cislo1 + Cislo2;
        }
        private float OdečtiFn(float Cislo1, float Cislo2)
        {
            return Cislo1 - Cislo2;
        }
        private float NásobFn(float Cislo1, float Cislo2)
        {
            return Cislo1 * Cislo2;
        }
        private float DělFn(float Cislo1, float Cislo2)
        {
            return Cislo1 / Cislo2;
        }
        private double MocniFn(double Cislo1)
        {
            return Math.Pow(Cislo1, 2);
        }
        private double OdmocniFn(double Cislo1)
        {
            return Math.Sqrt(Cislo1);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Vypočti_Click(object sender, EventArgs e)
        {
            string Operátor = "";
            switch (Operace)
            {
                    case 1:
                    Vysledek.Text = "= " + SečtiFn(float.Parse(textBox1.Text), float.Parse(textBox2.Text));
                    Operátor = " + ";
                    break;
                    case 2:
                    Vysledek.Text = "= " + OdečtiFn(float.Parse(textBox1.Text), float.Parse(textBox2.Text));
                    Operátor = " - ";
                    break;
                    case 3:
                    Vysledek.Text = "= " + NásobFn(float.Parse(textBox1.Text), float.Parse(textBox2.Text));
                    Operátor = " * ";
                    break;
                    case 4:
                    Vysledek.Text = "= " + DělFn(float.Parse(textBox1.Text), float.Parse(textBox2.Text));
                    Operátor = " : ";
                    break;
            }
            Čísla.Text = float.Parse(textBox1.Text) + Operátor + float.Parse(textBox2.Text);
            Čísla.Visible = true;
            Operace = 0;
            textBox1.Text = "";
            textBox2.Text = "";

            textBox2.Visible = false;

        }
    }
}
