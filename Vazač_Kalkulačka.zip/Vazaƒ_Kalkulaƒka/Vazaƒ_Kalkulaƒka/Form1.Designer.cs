﻿namespace Vazač_Kalkulačka
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Plus = new System.Windows.Forms.Button();
            this.Minus = new System.Windows.Forms.Button();
            this.Krát = new System.Windows.Forms.Button();
            this.Děleno = new System.Windows.Forms.Button();
            this.Mocnina = new System.Windows.Forms.Button();
            this.Odmocnina = new System.Windows.Forms.Button();
            this.Vysledek = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.Vypočti = new System.Windows.Forms.Button();
            this.Čísla = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.AcceptsReturn = true;
            this.textBox1.Location = new System.Drawing.Point(26, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(223, 20);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Plus
            // 
            this.Plus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Plus.Location = new System.Drawing.Point(12, 141);
            this.Plus.Name = "Plus";
            this.Plus.Size = new System.Drawing.Size(40, 35);
            this.Plus.TabIndex = 1;
            this.Plus.Text = "+";
            this.Plus.UseVisualStyleBackColor = true;
            this.Plus.Click += new System.EventHandler(this.Plus_Click);
            // 
            // Minus
            // 
            this.Minus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Minus.Location = new System.Drawing.Point(58, 141);
            this.Minus.Name = "Minus";
            this.Minus.Size = new System.Drawing.Size(40, 35);
            this.Minus.TabIndex = 2;
            this.Minus.Text = "-";
            this.Minus.UseVisualStyleBackColor = true;
            this.Minus.Click += new System.EventHandler(this.Minus_Click);
            // 
            // Krát
            // 
            this.Krát.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Krát.Location = new System.Drawing.Point(108, 141);
            this.Krát.Name = "Krát";
            this.Krát.Size = new System.Drawing.Size(40, 35);
            this.Krát.TabIndex = 3;
            this.Krát.Text = "*";
            this.Krát.UseVisualStyleBackColor = true;
            this.Krát.Click += new System.EventHandler(this.Krát_Click);
            // 
            // Děleno
            // 
            this.Děleno.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Děleno.Location = new System.Drawing.Point(154, 141);
            this.Děleno.Name = "Děleno";
            this.Děleno.Size = new System.Drawing.Size(40, 35);
            this.Děleno.TabIndex = 4;
            this.Děleno.Text = ":";
            this.Děleno.UseVisualStyleBackColor = true;
            this.Děleno.Click += new System.EventHandler(this.Děleno_Click);
            // 
            // Mocnina
            // 
            this.Mocnina.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Mocnina.Location = new System.Drawing.Point(209, 141);
            this.Mocnina.Name = "Mocnina";
            this.Mocnina.Size = new System.Drawing.Size(40, 35);
            this.Mocnina.TabIndex = 5;
            this.Mocnina.Text = "x²";
            this.Mocnina.UseVisualStyleBackColor = true;
            this.Mocnina.Click += new System.EventHandler(this.Mocnina_Click);
            // 
            // Odmocnina
            // 
            this.Odmocnina.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Odmocnina.Location = new System.Drawing.Point(209, 181);
            this.Odmocnina.Name = "Odmocnina";
            this.Odmocnina.Size = new System.Drawing.Size(40, 39);
            this.Odmocnina.TabIndex = 6;
            this.Odmocnina.Text = "2√";
            this.Odmocnina.UseVisualStyleBackColor = true;
            this.Odmocnina.Click += new System.EventHandler(this.Odmocnina_Click);
            // 
            // Vysledek
            // 
            this.Vysledek.AutoSize = true;
            this.Vysledek.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Vysledek.Location = new System.Drawing.Point(21, 88);
            this.Vysledek.Name = "Vysledek";
            this.Vysledek.Size = new System.Drawing.Size(93, 25);
            this.Vysledek.TabIndex = 7;
            this.Vysledek.Text = "Výsledek";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(26, 40);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(223, 20);
            this.textBox2.TabIndex = 8;
            this.textBox2.Visible = false;
            // 
            // Vypočti
            // 
            this.Vypočti.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Vypočti.Location = new System.Drawing.Point(12, 182);
            this.Vypočti.Name = "Vypočti";
            this.Vypočti.Size = new System.Drawing.Size(182, 35);
            this.Vypočti.TabIndex = 9;
            this.Vypočti.Text = "Vypočti";
            this.Vypočti.UseVisualStyleBackColor = true;
            this.Vypočti.Click += new System.EventHandler(this.Vypočti_Click);
            // 
            // Čísla
            // 
            this.Čísla.AutoSize = true;
            this.Čísla.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Čísla.Location = new System.Drawing.Point(21, 52);
            this.Čísla.Name = "Čísla";
            this.Čísla.Size = new System.Drawing.Size(150, 25);
            this.Čísla.TabIndex = 10;
            this.Čísla.Text = "51515 + 5151 =";
            this.Čísla.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(264, 219);
            this.Controls.Add(this.Čísla);
            this.Controls.Add(this.Vypočti);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.Vysledek);
            this.Controls.Add(this.Odmocnina);
            this.Controls.Add(this.Mocnina);
            this.Controls.Add(this.Děleno);
            this.Controls.Add(this.Krát);
            this.Controls.Add(this.Minus);
            this.Controls.Add(this.Plus);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button Plus;
        private System.Windows.Forms.Button Minus;
        private System.Windows.Forms.Button Krát;
        private System.Windows.Forms.Button Děleno;
        private System.Windows.Forms.Button Mocnina;
        private System.Windows.Forms.Button Odmocnina;
        private System.Windows.Forms.Label Vysledek;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button Vypočti;
        private System.Windows.Forms.Label Čísla;
    }
}

